<?php
//Database connection
include 'dbconnect.php';
$sl = 1;

$sqlString  = "SELECT t4, t5, t6, t8, t9, t10, t11, t12, t13, t15, t16, t17, t18, t22, t23, t24, t26, t27, t28, t30, t32, t33, t34, t35, t36, t37 FROM metrics;";
$sqlQuery   = mysqli_query($connect, $sqlString) or die(mysqli_error($connect));
$rows = ( $sqlQuery ) ? mysqli_num_rows($sqlQuery) : 0;

// init variables
// sum
$sum_total = 0;
$sum_comp = 0;
$sum_conect = 0;
$sum_consum = 0;
$sum_elec = 0;
$sum_fix = 0;
$sum_interop = 0;
$sum_public = 0;
$sum_real = 0;
$sum_sec = 0;

//average
$avg_total = 0;
$avg_comp = 0;
$avg_conect = 0;
$avg_consum = 0;
$avg_elec = 0;
$avg_fix = 0;
$avg_interop = 0;
$avg_public = 0;
$avg_real = 0;
$avg_sec = 0;
// loop for $sqlQuery
while( $record = mysqli_fetch_array($sqlQuery) )
{
	$sum_total = $record["t4"] + $record["t5"] + $record["t6"] + $record["t8"] + $record["t9"] + $record["t10"] + $record["t11"] + $record["t12"] + $record["t13"] + $record["t15"] + $record["t16"] + $record["t17"] + $record["t18"] + $record["t22"] + $record["t23"] + $record["t24"] + $record["t26"] + $record["t27"] + $record["t28"] + $record["t30"] + $record["t32"] + $record["t33"] + $record["t34"] + $record["t35"] + $record["t36"] + $record["t37"];
						
	$sum_comp = $record["t4"] + $record["t5"] + $record["t6"] + $record["t8"] + $record["t9"];
	$sum_conect = $record["t10"] + $record["t11"] + $record["t12"];
	$sum_consum = $record["t13"];
	$sum_elec = $record["t15"];
	$sum_fix = $record["t16"] + $record["t17"] + $record["t18"];
	$sum_interop = $record["t22"] + $record["t23"] + $record["t24"] + $record["t26"] + $record["t27"] + $record["t28"];
	$sum_public = $record["t30"];
	$sum_real = $record["t32"];
	$sum_sec = $record["t33"] + $record["t34"] + $record["t35"] + $record["t36"] + $record["t37"];
}
// resutl from $sqlQuery
$avg_total = number_format(($sum_total/26), 2);
$avg_comp = number_format(($sum_comp/5), 2);
$avg_conect = number_format(($sum_conect/3), 2);
$avg_consum = number_format(($sum_consum/1), 2);
$avg_elec = number_format (($sum_elec/1), 2);
$avg_fix = number_format (($sum_fix/3), 2);
$avg_interop = number_format (($sum_interop/6),2);
$avg_public = number_format (($sum_public/1),2);
$avg_real = number_format (($sum_real/1),2);
$avg_sec = number_format (($sum_sec/5),2);



// $sqlString1
$sqlString1  = "SELECT o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o18, o20, o21 FROM metrics1;";
$sqlQuery1   = mysqli_query($connect, $sqlString1) or die(mysqli_error($connect));
$rows1 = ( $sqlQuery1 ) ? mysqli_num_rows($sqlQuery1) : 0;

//init variables
//sum
$sum_total1 = 0;
$sum_awa = 0;
$sum_demo = 0;
$sum_Ehealth = 0;
$sum_ITKno = 0;
$sum_leader = 0;
$sum_orga = 0;
$sum_resou = 0;
$sum_size = 0;
$sum_top = 0;
$sum_train = 0;
$sum_trust = 0;

//averages
$avg_awa = 0;
$avg_total1 = 0;
$avg_demo = 0;
$avg_Ehealth = 0;
$avg_ITKno = 0;
$avg_leader = 0;
$avg_orga = 0;
$avg_resou = 0;
$avg_size = 0;
$avg_top = 0;
$avg_train = 0;
$avg_trust = 0;

// loop for $sqlQuery1
while( $record = mysqli_fetch_array($sqlQuery1) )
{
	$sum_total1 = $record["o1"] + $record["o2"] + $record["o3"] + $record["o4"] + $record["o5"] + $record["o6"] + $record["o7"] + $record["o8"] + $record["o9"] + $record["o10"] + $record["o11"] + $record["o12"] + $record["o13"] + $record["o14"] + $record["o18"] + $record["o20"] + $record["o21"];
	
	$sum_awa = $record["o1"] + $record["o2"];
	$sum_demo = $record["o3"];
	$sum_Ehealth = $record["o4"] + $record["o5"] + $record["o6"];
	$sum_ITKno = $record["o7"] + $record["o8"] + $record["o9"];
	$sum_leader = $record["o10"];
	$sum_orga = $record["o11"];
	$sum_resou = $record["o12"] + $record["o13"];
	$sum_size = $record["o14"];
	$sum_top = $record["o18"];
	$sum_train = $record["o20"];
	$sum_trust = $record["o21"];
}
// resutl from $sqlQuery1	
	$avg_total1 = number_format (($sum_total1/17),2);
	$avg_awa = number_format (($sum_awa/2),2);
	$avg_demo = number_format (($sum_demo/1),2);
	$avg_Ehealth = number_format (($sum_Ehealth/3),2);
	$avg_ITKno = number_format (($sum_ITKno/3),2);
	$avg_leader = number_format (($sum_leader/1),2);
	$avg_orga = number_format (($sum_orga/1),2);
	$avg_resou = number_format (($sum_resou/2),2);
	$avg_size = number_format (($sum_size/1),2);
	$avg_top = number_format (($sum_top/1),2);
	$avg_train = number_format (($sum_train/1),2);
	$avg_trust = number_format (($sum_trust/1),2);
	

$sqlString2  = "SELECT e1, e2, e3, e4, e5, e6, e7, e8, e9, e10, e11, e12, e13, e14, e15 FROM metrics2;";
$sqlQuery2   = mysqli_query($connect, $sqlString2) or die(mysqli_error($connect));
$rows2 = ( $sqlQuery2 ) ? mysqli_num_rows($sqlQuery2) : 0;

//init variables
//sum
$sum_total2 = 0;
$sum_acc = 0;
$sum_comm = 0;
$sum_compet = 0;
$sum_ext = 0;
$sum_exter = 0;
$sum_external = 0;
$sum_gov = 0;
$sum_inv = 0;
$sum_out = 0;
$sum_sha = 0;

//averages
$avg_total2 = 0;
$avg_acc = 0;
$avg_comm = 0;
$avg_compet = 0;
$avg_ext = 0;
$avg_exter = 0;
$avg_external = 0;
$avg_gov = 0;
$avg_inv = 0;
$avg_out = 0 ;
$avg_sha = 0;

// loop for $sqlQuery2
while( $record = mysqli_fetch_array($sqlQuery2) )
{
	$sum_total2 = $record["e1"] + $record["e2"] + $record["e3"] + $record["e4"] + $record["e5"] + $record["e6"] + $record["e7"] + $record["e8"] + $record["e9"] + $record["e10"] + $record["e11"] + $record["e12"] + $record["e13"] + $record["e14"] + $record["e15"];
	
	$sum_acc = $record["e1"] + $record["e2"];
	$sum_comm = $record["e3"];
	$sum_compet = $record["e4"];
	$sum_ext = $record["e5"];
	$sum_exter = $record["e6"] + $record["e7"];
	$sum_external = $record["e8"];
	$sum_gov = $record["e9"];
	$sum_inv = $record["e10"] + $record["e11"];
	$sum_out = $record["e12"];
	$sum_sha = $record["e13"] + $record["e14"] + $record["e15"];
		
}

// resutl from $sqlQuery2
	$avg_total2 = number_format (($sum_total2/15),2);
	$avg_acc = number_format (($sum_acc/2),2);
	$avg_comm = number_format (($sum_comm/1),2);
	$avg_compet = number_format (($sum_compet/1),2);
	$avg_ext = number_format (($sum_ext/1),2);
	$avg_exter = number_format (($sum_exter/2),2);
	$avg_external = number_format (($sum_external/1),2);
	$avg_gov = number_format (($sum_gov/1),2);
	$avg_inv = number_format (($sum_inv/2),2);
	$avg_out = number_format (($sum_out/1),2);
	$avg_sha =number_format (($sum_sha/3),2);

$sqlString3  = "SELECT pr1, pr2, pr3, pr5, pr6, pr7, pr8 FROM metrics3;";
$sqlQuery3   = mysqli_query($connect, $sqlString3) or die(mysqli_error($connect));
$rows3 = ( $sqlQuery3 ) ? mysqli_num_rows($sqlQuery3) : 0;

//init variables
//sum
$sum_total3 = 0;
$sum_intel = 0;
$sum_proc = 0;
$sum_tax = 0;
$sum_impor = 0;
$sum_gover = 0;
$sum_nat = 0;


//averages
$avg_total3 = 0;
$avg_intel = 0;
$avg_proc = 0;
$avg_tax = 0;
$avg_impor = 0;
$avg_gover = 0;
$avg_nat = 0;

// loop for $sqlQuery3
while( $record = mysqli_fetch_array($sqlQuery3) )
{
	$sum_total3 = $record["pr1"] + $record["pr2"] + $record["pr3"] + $record["pr5"] + $record["pr6"] + $record["pr7"] + $record["pr8"];
	
	$sum_intel = $record["pr1"];
	$sum_proc = $record["pr2"];
	$sum_tax = $record["pr3"];
	$sum_impor = $record["pr5"];
	$sum_gover = $record["pr6"] + $record["pr7"];
	$sum_nat = $record["pr8"];
	
}

// resutl from $sqlQuery3

$avg_total3 = number_format (($sum_total3/7),2);
$avg_intel = number_format (($sum_intel/1),2);
$avg_proc = number_format (($sum_proc/1),2);
$avg_tax = number_format (($sum_tax/1),2);
$avg_impor = number_format (($sum_impor/1),2);
$avg_gover = number_format (($sum_gover/2),2);
$avg_nat = number_format (($sum_nat/1),2);

	$avg_totalAll = number_format ((($avg_total + $avg_total1 + $avg_total2 + $avg_total3)/4),2);
	

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>ARAT-BDA | Results</title>
	<!-- charts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
	
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
	<!-- charts -->
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
	<script src="js/Chart.js/dist/Chart.bundle.js"></script>
  
    <style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    </style>
  
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"> <span>ARAT</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                
                <ul class="nav side-menu">
                    <li><a href="index.html"><i></i> Home <span></span></a>  
				
				<li><a href="tec.html"><i class="fa fa-edit"></i> Technological context<span ></span></a>
                  </li> 
				  <li><a href="org.html"><i class="fa fa-edit"></i> Organizational context<span ></span></a>
                  </li> 
				  <li><a href="env.html"><i class="fa fa-edit"></i> Environmental context<span ></span></a>
                  </li> 
				  <li><a href="pol.html"><i class="fa fa-edit"></i> Political & regulatory context<span ></span></a>
                  </li> 
                 
                  <li class="active"><a href="displayRecords.php"><i class="fa fa-bar-chart-o"></i> Assessment results <span></span></a>
                  </li>
                 
                </ul>
              </div>
              
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
         
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="row top_tiles">
              <div class="animated flipInY col-lg-6 col-md-6 col-sm-8 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i></i></div>
                  <div class="count">ARAT/BDA</div>
                  <h3>Assessment Results</h3>
                  <p></p>
                </div>
              </div>
              <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i></i></div>
                  <div class="count"> <a href="" onclick="window.print();return false;"/><img src="images/print.png" onclick="window.print();return false;"/></a></div>
                  <h3></h3>
                  <p></p>
                </div>
              </div>
             <!--<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i></i></div>
                  <div class="count">0000</div>
                  <h3>New Sign ups</h3>
                  <p>Lorem ipsum psdea itgum rixt.</p>
                </div>
              </div>
              <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-check-square-o"></i></div>
                  <div class="count">179</div>
                  <h3>New Sign ups</h3>
                  <p>Lorem ipsum psdea itgum rixt.</p>
                </div>
              </div> -->
            </div>

            <div class="row">
              <div class="col-md-10">
                <div class="x_panel">
                  <div class="x_title">
				  <button class="btn btn-primary" type="reset">I. TECHNOLOGICA CONTEXT</button><br/>
                    <h4>1. Compatibility:  <?php echo $avg_comp;?> 

					</h4>
					
					<h4>2. Connectivity: <?php echo $avg_conect; ?>

					</h4>
					
					<h4>3. Consumer sensitivity: <?php echo $avg_consum; ?>

					</h4>
					
					<h4>4. Electricity production: <?php echo $avg_elec; ?>

					</h4>
					
					<h4>5. Fixed broadband: <?php echo $avg_fix; ?>

					</h4>
					
					<h4>6. Interoperability between healthcare facilities and standards of interoperability: <?php echo $avg_interop; ?>

					</h4>
					
					<h4>7. Public health informatics (ICTs, public health information systems): <?php echo $avg_public; ?>

					</h4>
					
					<h4>8. Real-time decision making: <?php echo $avg_real; ?>

					</h4>
					
					<h4>9. Security and privacy issues: <?php echo $avg_sec; ?>

					</h4>
					<div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					</button>
					<h4>Technological context readiness level: <?php echo $avg_total; ?></h4>
				
				</div>
				<div class="x_title">
				  <button class="btn btn-primary" type="reset">II. ORGANIZATIONAL CONTEXT</button><br/>
                    <h4>1. Awareness about the innovation: <?php echo $avg_awa; ?>
					
					

					</h4>
					
					<h4>2. Demographic variables: <?php echo $avg_demo; ?>

					</h4>
					
					<h4>3. E-health capacity building of healthcare workers: <?php echo $avg_Ehealth; ?>

					</h4>
					
					<h4>4. IT knowledge: <?php echo $avg_ITKno; ?>

					</h4>
					
					<h4>5. Leardership attitude towards the innovation: <?php echo $avg_leader; ?>

					</h4>
					
					<h4>6. Resource availability (Finances): <?php echo $avg_resou; ?>

					</h4>
					
					<h4>7. Size: <?php echo $avg_size; ?>

					</h4>
					
					<h4>8. Top management support: <?php echo $avg_top; ?>

					</h4>
					
					<h4>9. Training and experience: <?php echo $avg_train; ?>

					</h4>
				
					<h4>10. Trust in the use of ICT: <?php echo $avg_trust; ?>

					</h4>
					
					<div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					</button>
					<h4>Organizational context readiness level: <?php echo $avg_total1; ?>
					
					
					
					</h4>
					
                    <div class="clearfix"></div>
  </div>
  <div class="x_title">
				  <button class="btn btn-primary" type="reset">III. ENVIRONMENTAL CONTEXT</button><br/>
                    <h4>1. Access to information by patients  and health workers: <?php echo $avg_acc; ?>

					</h4>
					
					<h4>2. Communication with other organizations: <?php echo $avg_comm; ?>
		
					</h4>
					
					<h4>3. Competitive pressure: <?php echo $avg_compet; ?>
		
					</h4>
					
					<h4>4. External environment: <?php echo $avg_ext; ?>
		
					</h4>
					
					<h4>5. External pressure: <?php echo $avg_exter; ?>
		
					</h4>
					
					<h4>6. External resources: <?php echo $avg_external; ?>
					</h4>
					
					<h4>7. Government pressure: <?php echo $avg_gov; ?>
					</h4>
					
					<h4>8. Involvement of healthcare providers in innovation: <?php echo $avg_inv; ?>
					</h4>
					
					<h4>9. Outside support: <?php echo $avg_out; ?>
					</h4>
					
					<h4>10. Sharing of data between healthcare facilities: <?php echo $avg_sha; ?>
					</h4>
					<div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					</button>
					<h4>Environmental context readiness level: <?php echo $avg_total2; ?>
					
					
					
					</h4>
				</div>
				<div class="x_title">
				  <button class="btn btn-primary" type="reset">IV. POLITICAL & REGULATORY CONTEXT</button><br/>
                    <h4>1. Intellectual property protection: <?php echo $avg_intel; ?>

					</h4>
					
					<h4>2. Procedures to enforce a contract: <?php echo $avg_proc; ?>

					</h4>
					
					<h4>3. Tax rate: <?php echo $avg_tax; ?>

					</h4>
					
					<h4>4. Importance of ICT to the government vision of the future: <?php echo $avg_impor; ?>

					</h4>
					
					<h4>5. Government success in ICT promotion: <?php echo $avg_gover; ?>

					</h4>
					
					<h4>6. National e-Health policies: <?php echo $avg_nat; ?>

					</h4>
					
					
					<div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					</button>
					<h4>Political context readiness level: <?php echo $avg_total3; ?>

					</h4>
				</div>
				
            <!-- Table Header -->

            <!-- Table Body -->
            

                    <div class="col-md-12 col-sm-12 col-xs-12">
					<h1>FULL ASSESSMENT REPORT</h1>
                      <div>
					  <h4>General adoption readiness level: <?php echo $avg_totalAll; ?></h4></br>
					  <!-- GRAPH -->
					  
					  
					   <!-- technological context -->
                        <button class="btn btn-primary" type="reset">Technological context </button>
                       <!-- compatibility -->
					  <p> <?php if ($avg_comp<3){
								echo '- Increase the number of computers in hospitals, increase the RAM capacity of computers in hospitas, upgrade the Operating Systems used up to Windows 8 or 10, implement the same software application to all the hospitals and implement LANs into all the hospitals';
								
							}
							else{
								echo '- The number of computers in hospitals is sufficient, they are using good Operating systems, assure that all the hospitals use the same software application and that all the hospitals have LANs.';
							}
							
					  ?></p></hr>
					   <!-- connectivity -->
					 <p> <?php if ($avg_conect<5){
								echo '- Provide internet to all the hospitals, interconnect all the the hospitals to one metropolitan network. (connect them to a fiber optic network if there is any). ';
								
							}
							else{
								echo '- All the hospitals have an internet and they are interconnected to a same fiber metropolitan network.';
							}
							?></p></hr>
							<!-- consumer sensitivity -->
							<p><?php if ($avg_consum < 4){
								echo '- Inform the healthcare workers about the importance of having a BDA system and all its advantages for the patients. ';
								
							}
							else{
								echo '- The healthcare workers are aware of the benefits that a BDA system has..';
							}

					  ?></p></hr>
					  <!-- electricity production -->
							<p><?php if ($avg_elec < 5){
								echo '- Increase electricity supply to hospitals or provide power generators to assure a 24 hours coverage. ';
								
							}
							else{
								echo '- The hospitals are provided with sufficient electricity.';
							}
	
							
					  ?></p></hr>
					  <!-- Fixed broadband -->
							<p><?php if ($avg_fix < 4){
								echo '- Implement a nation-wide metropolitan network of fiber. If existing, increase its coverage up to 75% nation-wide and make sure that its network availability is 99.99%  ';
								
							}
							else{
								echo '- The country has a metropolitan network of fiber that covers up to 75% of the country with a network availability of 99.99%.';
							}
					  ?></p></hr>
					  <!-- interoperability -->
							<p><?php if ($avg_interop < 5){
								echo '- Interconnect all the hospitals to the ministry of health using the same network, implement standards of interoperability between hospitals and data storage standards.';		
							}
							else{
								echo '- The hospitals are interconnected to the ministry of health and the country has standards of interoperability and data storage for hospitals.';
							}
					  ?></p></hr>
					  <!-- public health informatic  -->
							<p><?php if ($avg_public < 5){
								echo '- Implement the same software application in all the hospitals.';		
							}
							else{
								echo '- All the hospitals use the same software application.';
							}
					  ?></p></hr>
					   <!-- real-time decision making  -->
							<p><?php if ($avg_real < 5){
								echo '- Implement a BDA system that can generate reports in real-time.';		
							}
							else{
								echo '- The BDA system can generate reports in real-time.';
							}
					  ?></p></hr>
					  <!-- security & privacy  -->
							<p><?php if ($avg_sec < 5){
								echo '- Increase the level of security in the hospitals, increase the level of security of the internet connections and the interconnection between hospitals and the ministry of health. Assure the health information privacy policy is well implemented if existing.';		
							}
							else{
								echo '- The security level at the hospitals is good. The internet connection and the interconnection between hospitals and the ministry is secured. The country health information privacy policy is well implemented. ';
							}
					  ?></p></hr>
					  <!-- organizational context -->
                        <button class="btn btn-primary" type="reset">Organizational context </button>
					  <!-- awareness  -->
							<p><?php if ($avg_awa < 5){
								echo '- The ministry officials should be informed about BDA systems and be aware of their benefits in healthcare.';		
							}
							else{
								echo '- The ministry officials are fully aware of BDA systems benefits.';
							}
					  ?></p></hr>
					  <!-- demographic variables  -->
							<p><?php if ($avg_demo > 2){
								echo '- The number of patients received per day in hospitals is big enough for a BDA system usage.';		
							}
							else{
								echo '- The number of patients in hospitals is low for a BDA system.';
							}
					  ?></p></hr>
					  <!-- E-health capacity building of healthcare workers  -->
							<p><?php if ($avg_Ehealth < 5){
								echo '- The ministry and hospitals should increase the number of ICT trainings.';		
							}
							else{
								echo '- Healthcare workers are trained enough.';
							}
					  ?></p></hr>
					   <!-- IT knowledge  -->
							<p><?php if ($avg_ITKno < 5){
								echo '- The hospitals and ministry use the same software application to store and collect data. The IT officers in hospitals are highly qualified.';		
							}
							else{
								echo '- The ministry should implement the same software application in all the hospitals and hire qualified IT officers.';
							}
					  ?></p></hr>
					  <!-- Leadership attitude towards the innovation -->
							<p><?php if ($avg_leader < 5){
								echo '- The ministry officials should support new technology adoption.';		
							}
							else{
								echo '- The ministry officials support the adoption of new technology adoption.';
							}
					  ?></p></hr>
					  <!-- Is the use of ICT included in the hospital’s culture? -->
							<p><?php if ($avg_orga < 5){
								echo '- Hospitals should include the use of ICT in their culture.';		
							}
							else{
								echo '- The hospitals include the use of ICT in their culture.';
							}
					  ?></p></hr>
					  <!-- Do the hospitals have a budget for innovation projects? -->
							<p><?php if ($avg_resou < 4){
								echo '- Hospitals should provide financial resources if possible for new technology adoption.';		
							}
							else{
								echo '- Hospitals have available financial resources to support new technology adoption.';
							}
					  ?></p></hr>
					  <!-- Do the hospitals have a budget for innovation projects? -->
							<p><?php if ($avg_size < 3){
								echo '- Hospitals should hire enough employees to assure that the BDA system is fully functional.';		
							}
							else{
								echo '- Hospitals have enough employees to assure that the BDA system is fully functional.';
							}
					  ?></p></hr>
					  <!-- Top management support -->
							<p><?php if ($avg_top < 5){
								echo '- The ministry is not willing not support the adoption of the BDA system.';		
							}
							else{
								echo '- The ministry is willing not support the adoption of the BDA system.';
							}
					  ?></p></hr>
					   <!-- Training and experience -->
							<p><?php if ($avg_train < 4){
								echo '- Healthcare workers are not trained frequently in ICT usage.';		
							}
							else{
								echo '- Healthcare workers are trained frequently in ICT usage.';
							}
					  ?></p></hr>
					  <!-- Trust in the use of ICT -->
							<p><?php if ($avg_trust < 5){
								echo '- Hospitals management do not fully trust the use of ICT.';		
							}
							else{
								echo '- Hospitals management fully trust the use of ICT.';
							}
					  ?></p></br>
					   <!-- organizational context -->
                        <button class="btn btn-primary" type="reset">Environmental context </button>
					  <!-- Access to information by patients  and health workers  -->
					  <p><?php if ($avg_acc <5){
								echo '- Hospitals should allow patients to access their health records online if the health information policies allow it.';		
							}
							else{
								echo '- Assure that patients can access their health records online.';
							}
					  ?></p>
					   <!-- Communication with other organizations  -->
					  <p><?php if ($avg_comm <5){
								echo '- Hospitals should be interconnected with laboratories and other health institutions to enable collaboration.';		
							}
							else{
								echo '- The hospitals are interconnected with laboratories and other health institutions.';
							}
					  ?></p>
					   <!-- Competitive pressure  -->
					  <p><?php if ($avg_compet <2){
								echo '- The number of african countries using BDA systems in healthcare services is very low.';		
							}
							else{
								echo '- The number of african countries using BDA systems in healthcare services is good.';
							}
					  ?></p>
					   <!-- External environment  -->
					  <p><?php if ($avg_ext <2){
								echo '- The number of neighbouring countries using BDA systems in healthcare services is very low.';		
							}
							else{
								echo '- The number of african countries using BDA systems in healthcare services is good.';
							}
					  ?></p>
					  <!-- External pressure  -->
					  <p><?php if ($avg_exter <5){
								echo '- There are no regional interconnections of healthcare institutions.';		
							}
							else{
								echo '- The country is part of a regional interconnection of healthcare institutions.';
							}
					  ?></p>
					  <!-- External resources  -->
					  <p><?php if ($avg_external <5){
								echo '- The government does not have any external financial support. The country needs to partner with other countries that are willing to support it.';		
							}
							else{
								echo '- The country has external financial support willing to sponsor the adoption of the BDA system.';
							}
					  ?></p>
					  <!-- Government pressure  -->
					  <p><?php if ($avg_gov <5){
								echo '- The government has no intention of adopting a BDA system.';		
							}
							else{
								echo '- The government has the intention of adpopting a BDA system in healthcare.';
							}
					  ?></p>
					   <!-- Involvement of healthcare providers in innovation  -->
					  <p><?php if ($avg_inv<5){
								echo '- Hospitals should get more involved in technological inovations in the healthcare sector.';		
							}
							else{
								echo '- Hospitals contribute in technological inovations in the healthcare sector.';
							}
					  ?></p>
					  <!-- Outside support  -->
					  <p><?php if ($avg_out <5){
								echo '- The government needs an external partner that is willing to offer technical support.';		
							}
							else{
								echo '- The government has external technical support.';
							}
					  ?></p>
					  <!-- Sharing of data between healthcare facilities  -->
					  <p><?php if ($avg_sha <5){
								echo '- Hospitals are not sharing information between them enough and the methods used are not effective.';		
							}
							else{
								echo '- The hospitals are sharing information between them and are using effective methods.';
							}
					  ?></p></br>
					  <button class="btn btn-primary" type="reset">Political & Regulatory context </button>
					  <!-- Intellectual property protection  -->
					  <p><?php if ($avg_intel <5){
								echo '- The country needs a policy on health information protection.';		
							}
							else{
								echo '- The country has a health information protection policy.';
							}
					  ?></p>
					  <!-- Procedures to enforce a contract  -->
					  <p><?php if ($avg_proc <4){
								echo '- The government needs to improve the actual procedure to enforce a contract of purchasing a Health Information system.';		
							}
							else{
								echo '- The actual procedure to enforce a contract of purchasing a Health Information system is fast.';
							}
					  ?></p>
					   <!-- Tax rate -->
					  <p><?php if ($avg_tax <4){
								echo '- The government needs to reduce the tax rates on new health technology.';		
							}
							else{
								echo '- The actual tax rates on new health technology are low.';
							}
					  ?></p>
					   <!-- Importance of ICT to the government vision of the future -->
					  <p><?php if ($avg_impor <5){
								echo '- The government should include the importance of using ICT in healthcare in its vision for the future.';		
							}
							else{
								echo '- The government includes the importance of using ICT in healthcare in its vision for the future.';
							}
					  ?></p>
					  <!-- Government success in ICT promotion -->
					  <p><?php if ($avg_gover < 3){
								echo '- The government should promote technological innovations in the healthcare sector.';		
							}
							else{
								echo '- The government promotes technological innovations in the healthcare sector.';
							}
					  ?></p>
					   <!-- National e-Health policies -->
					  <p><?php if ($avg_nat < 5){
								echo '- The government should adopt a e-health policy.';		
							}
							else{
								echo '- The government has adopted a e-health policy.';
							}
					  ?></p></br>
					  <h4>GRAPHS</h4>
					  <div class="col-md-12 col-sm-10 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>General adoption readiness level</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div id="canvas-holder" style="width:85%">
        <canvas id="general"></canvas>
    </div>

                  </div>
				  </br>
				  
                </div>
              </div>
			  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Technological readiness level</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div style="width:85%">
        <canvas id="tech"></canvas>
    </div>

                  </div>
					  
					  </div>
					  
					  </div></br>
					  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Organizational readiness level</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div style="width:85%">
        <canvas id="org"></canvas>
    </div>

                  </div>
					  </div>
					  
					  
					  </div></br>
					  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Environmental readiness level</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div style="width:85%">
        <canvas id="env"></canvas>
    </div>

                  </div>
					  </div>
					  
					  
					  </div></br>
					  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Political & Regulatory readiness level</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                     <div style="width:85%">
        <canvas id="pol"></canvas>
    </div>

                  </div>
					  </div>
					  
					  
					  </div>
                    </div>

                  
         

            <div class="row">
              
              </div>
            </div>

          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            ARAT - Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
	    <!-- ECharts -->
    <script src="../vendors/echarts/dist/echarts.min.js"></script>
    <script src="../vendors/echarts/map/js/world.js"></script>
    <!-- Chart.js -->
	 <script src="../vendors/echarts/dist/echarts.min.js"></script>
    <script src="../vendors/echarts/map/js/world.js"></script>
    <script src="../vendors/Chart.js/dist/Chart.min.js"></script>
	<script src=" ../vendors/raphael/raphael.min.js"></script>
	<script src="../vendors/morris.js/morris.min.js"></script>
    <!-- jQuery Sparklines -->
    <script src="../vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
    <!-- Flot -->
    <script src="../vendors/Flot/jquery.flot.js"></script>
    <script src="../vendors/Flot/jquery.flot.pie.js"></script>
    <script src="../vendors/Flot/jquery.flot.time.js"></script>
    <script src="../vendors/Flot/jquery.flot.stack.js"></script>
    <script src="../vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="../vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="../vendors/DateJS/build/date.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
		
					<!-- script for charts -->
	<!-- script for general level of readiness graph -->				
	 <script>
	function generateGraph () {
		var randomScalingFactor = function() {
			return Math.round(Math.random() * 5);
		};

		var config1 = {
			type: 'radar',
			data: {
				labels: ["technological", "organizational", "environmental", "political & regulatory"],
				datasets: [{
				
					borderColor: 'rgb(255, 0, 0)',
					backgroundColor: "rgba(255,255,0,0.5)",
					pointBackgroundColor: "rgba(220,220,220,1)",
					data: [<?php echo $avg_total; ?>,<?php echo $avg_total1; ?>,<?php echo $avg_total2; ?>,<?php echo $avg_total3; ?>]
				}, ]
			},
			options: {
				title:{
					display:true,
					text:"General assessment level"
				},
				elements: {
					line: {
						tension: 0.0,
					}
				},
				scale: {
					beginAtZero: true,
					reverse: false
				}
			}
		};
		
		

		var config2 = {
			type: 'radar',
			data: {
				labels: ["Compatibility", "Connectivity", "Consumer sensitivity", "Electricity Production", "Fixed Broadband", "Interoperability", "Public health informatics","Real-time decision making","Security and privacy issues"],
				datasets: [{
					
					borderColor: 'rgb(255, 0, 0)',
					backgroundColor: "rgba(255,255,0,0.5)",
					pointBackgroundColor: "rgba(220,220,220,1)",
					data: [<?php echo $avg_comp; ?>,<?php echo $avg_conect; ?>,<?php echo $avg_consum; ?>,<?php echo $avg_elec; ?>,<?php echo $avg_fix;?>,<?php echo $avg_interop; ?>,<?php echo $avg_public; ?>,<?php echo $avg_real; ?>,<?php echo $avg_sec; ?> ]
				}]
			},
			options: {
				title:{
					display:true,
					text:"Technological readiness level"
				},
				elements: {
					line: {
						tension: 0.0,
					}
				},
				scale: {
					beginAtZero: true,
					reverse: false
				}
			}
		};
		var config3 = {
			type: 'radar',
			data: {
				labels: ["Awareness", "Demographic variables", "E-health capacity building", "IT knowledge", "Leardership attitude towards the innovation", "Organizational culture", "Resource availability ","Size","Top management support","Training and experience","Trust in the use of ICT"],
				datasets: [{
					
					borderColor: 'rgb(255, 0, 0)',
					backgroundColor: "rgba(255,255,0,0.5)",
					pointBackgroundColor: "rgba(220,220,220,1)",
					data: [<?php echo $avg_awa; ?>,<?php echo $avg_demo; ?>,<?php echo $avg_Ehealth; ?>,<?php echo $avg_ITKno; ?>,<?php echo $avg_leader; ?>,<?php echo $avg_orga;?>,<?php echo $avg_resou; ?>,<?php echo $avg_size; ?>,<?php echo $avg_top; ?>,<?php echo $avg_train; ?>,<?php echo $avg_trust; ?> ]
				}]
			},
			options: {
				title:{
					display:true,
					text:"Organizational readiness level"
				},
				elements: {
					line: {
						tension: 0.0,
					}
				},
				scale: {
					beginAtZero: true,
					reverse: false
				}
			}
		};
		var config4 = {
			type: 'radar',
			data: {
				labels: ["Access to information by patients  and health workers", "Communication with other organizations", "Competitive pressure", "External environment", "External pressure", "External resources", "Government pressure ","Involvement of healthcare providers in innovation","Outside support","Sharing of data between healthcare facilities"],
				datasets: [{
					
					borderColor: 'rgb(255, 0, 0)',
					backgroundColor: "rgba(255,255,0,0.5)",
					pointBackgroundColor: "rgba(220,220,220,1)",
					data: [<?php echo $avg_acc; ?>,<?php echo $avg_comm; ?>,<?php echo $avg_compet; ?>,<?php echo $avg_ext; ?>,<?php echo $avg_exter;?>,<?php echo $avg_external; ?>,<?php echo $avg_gov; ?>,<?php echo $avg_inv; ?>,<?php echo $avg_out; ?>,<?php echo $avg_sha; ?> ]
				}]
			},
			options: {
				title:{
					display:true,
					text:"Environmental readiness level"
				},
				elements: {
					line: {
						tension: 0.0,
					}
				},
				scale: {
					beginAtZero: true,
					reverse: false
				}
			}
		};
		var config5 = {
			type: 'radar',
			data: {
				labels: ["Intellectual property protection", "Procedures to enforce a contract", "Tax rate", "Importance of ICT to the government vision of the future", "Government success in ICT promotion", "National e-Health policies"],
				datasets: [{
					
					borderColor: 'rgb(255, 0, 0)',
					backgroundColor: "rgba(255,255,0,0.5)",
					pointBackgroundColor: "rgba(220,220,220,1)",
					data: [<?php echo $avg_intel; ?>,<?php echo $avg_proc; ?>,<?php echo $avg_tax; ?>,<?php echo $avg_impor; ?>,<?php echo $avg_gover;?>,<?php echo $avg_nat; ?>]
				}]
			},
			options: {
				title:{
					display:true,
					text:"Political & regulatory readiness level"
				},
				elements: {
					line: {
						tension: 0.0,
					}
				},
				scale: {
					beginAtZero: true,
					reverse: false
				}
			}
		};

		window.onload = function() {
			//window.myRadar = new Chart(document.getElementById("canvas"), config);
			
			var ctx = document.getElementById("general");
			window.myRadar = Chart.Radar(ctx, config1);
			
			
			var ctx = document.getElementById("tech");
			window.myRadar = Chart.Radar(ctx, config2);
			
			var ctx = document.getElementById("org");
			window.myRadar = Chart.Radar(ctx, config3);
			
			var ctx = document.getElementById("env");
			window.myRadar = Chart.Radar(ctx, config4);
			
			var ctx = document.getElementById("pol");
			window.myRadar = Chart.Radar(ctx, config5);
			
		};

		
	}
	generateGraph();
    </script>
		
	
  </body>
</html>
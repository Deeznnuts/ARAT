<?php
//Database connection
include 'dbconnect.php';

// initials
$error = "";
$success = "";
$sql = "";

 //echo '<pre>';print_r($_POST);echo '</pre>';exit();

// when submit the form
if (isset($_POST['submit']))
{
    // Receiving POST Values
    
	$o1 = (isset($_POST["o1"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o1"]))) : "" );
	$o2 = (isset($_POST["o2"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o2"]))) : "" );
	$o3 = (isset($_POST["o3"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o3"]))) : "" );
	$o4 = (isset($_POST["o4"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o4"]))) : "" );
	$o5 = (isset($_POST["o5"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o5"]))) : "" );
	$o6 = (isset($_POST["o6"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o6"]))) : "" );
	$o7 = (isset($_POST["o7"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o7"]))) : "" );
	$o8 = (isset($_POST["o8"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o8"]))) : "" );
	$o9 = (isset($_POST["o9"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o9"]))) : "" );
	$o10 = (isset($_POST["o10"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o10"]))) : "" );
	$o11 = (isset($_POST["o11"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o11"]))) : "" );
	$o12 = (isset($_POST["o12"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o12"]))) : "" );
	$o13 = (isset($_POST["o13"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o13"]))) : "" );
	$o14 = (isset($_POST["o14"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o14"]))) : "" );
	$o18 = (isset($_POST["o18"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o18"]))) : "" );
	$o20 = (isset($_POST["o20"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o20"]))) : "" );
	$o21 = (isset($_POST["o21"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["o21"]))) : "" );

    // Insert the data into 'metrics1' table
    $sql = "INSERT INTO metrics1
                            (
                                  o1
								, o2
                                , o3
                                , o4
							    , o5
								, o6
								, o7
								, o8
								, o9
								, o10
								, o11
								, o12
								, o13
								, o14
								, o18
								, o20
								, o21
                            ) VALUES(
                                  '$o1'
                                , '$o2'
                                , '$o3'
								, '$o4'
								, '$o5'
								, '$o6'
								, '$o7'
								, '$o8'
								, '$o9'
								, '$o10'
								, '$o11'
								, '$o12'
								, '$o13'
								, '$o14'
								, '$o18'
								, '$o20'
								, '$o21'
                            )";

   // echo $sql;
    $query = mysqli_query($connect, $sql);
    // $latestId = mysqli_insert_id($connect);
    
    if($query)
    {
        echo '<script type="text/javascript">
                alert("Record save successfully.");
                window.location.replace("org.html");
            </script>';
    }
    else {
        $error = 'Failed to save records!';
    }
}

?>
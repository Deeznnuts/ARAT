CREATE DATABASE `arat`;

USE `arat`;

/*Table structure for table `metrics` */

DROP TABLE IF EXISTS `metrics`;

CREATE TABLE `metrics` (
  `t4` int(1) NOT NULL,
  `t5` int(1) NOT NULL,
  `t6` int(1) NOT NULL,
  `t8` int(1) NOT NULL,
  `t9` int(1) NOT NULL,
  `t10` int(1) NOT NULL,
  `t11` int(1) NOT NULL,
  `t12` int(1) NOT NULL,
  `t13` int(1) NOT NULL,
  `t15` int(1) NOT NULL,
  `t16` int(1) NOT NULL,
  `t17` int(1) NOT NULL,
  `t18` int(1) NOT NULL,
  `t22` int(1) NOT NULL,
  `t23` int(1) NOT NULL,
  `t24` int(1) NOT NULL,
  `t26` int(1) NOT NULL,
  `t27` int(1) NOT NULL,
  `t28` int(1) NOT NULL,
  `t30` int(1) NOT NULL,
  `t32` int(1) NOT NULL,
  `t33` int(1) NOT NULL,
  `t34` int(1) NOT NULL,
  `t35` int(1) NOT NULL,
  `t36` int(1) NOT NULL,
  `t37` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Table structure for table `metrics1` */

DROP TABLE IF EXISTS `metrics1`;

CREATE TABLE `metrics1` (
  `o1` int(1) NOT NULL,
  `o2` int(1) NOT NULL,
  `o3` int(1) NOT NULL,
  `o4` int(1) NOT NULL,
  `o5` int(1) NOT NULL,
  `o6` int(1) NOT NULL,
  `o7` int(1) NOT NULL,
  `o8` int(1) NOT NULL,
  `o9` int(1) NOT NULL,
  `o10` int(1) NOT NULL,
  `o11` int(1) NOT NULL,
  `o12` int(1) NOT NULL,
  `o13` int(1) NOT NULL,
  `o14` int(1) NOT NULL,
  `o18` int(1) NOT NULL,
  `o20` int(1) NOT NULL,
  `o21` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;


/*Table structure for table `metrics2` */

DROP TABLE IF EXISTS `metrics2`;

CREATE TABLE `metrics2` (
  `e1` int(1) NOT NULL,
  `e2` int(1) NOT NULL,
  `e3` int(1) NOT NULL,
  `e4` int(1) NOT NULL,
  `e5` int(1) NOT NULL,
  `e6` int(1) NOT NULL,
  `e7` int(1) NOT NULL,
  `e8` int(1) NOT NULL,
  `e9` int(1) NOT NULL,
  `e10` int(1) NOT NULL,
  `e11` int(1) NOT NULL,
  `e12` int(1) NOT NULL,
  `e13` int(1) NOT NULL,
  `e14` int(1) NOT NULL,
  `e15` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;


/*Table structure for table `metrics3` */

DROP TABLE IF EXISTS `metrics3`;

CREATE TABLE `metrics3` (
  `pr1` int(1) NOT NULL,
  `pr2` int(1) NOT NULL,
  `pr3` int(1) NOT NULL,
  `pr5` int(1) NOT NULL,
  `pr6` int(1) NOT NULL,
  `pr7` int(1) NOT NULL,
  `pr8` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;
<?php
//Database connection
include 'dbconnect.php';

// initials
$error = "";
$success = "";
$sql = "";

// echo '<pre>';
 //print_r($_POST);
 //echo '</pre>';
//exit

// when submit the form
if (isset($_POST['submit']))
{
    // Receiving POST Values
	$pr1 = (isset($_POST["pr1"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr1"]))) : "" );
	$pr2 = (isset($_POST["pr2"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr2"]))) : "" );
	$pr3 = (isset($_POST["pr3"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr3"]))) : "" );
	$pr5 = (isset($_POST["pr5"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr5"]))) : "" );
	$pr6 = (isset($_POST["pr6"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr6"]))) : "" );
	$pr7 = (isset($_POST["pr7"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr7"]))) : "" );
	$pr8 = (isset($_POST["pr8"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["pr8"]))) : "" );

    // Insert the data into 'metrics3' table
    $sql = "INSERT INTO metrics3
                            (
                                  pr1
								, pr2
                                , pr3
                                , pr5
							    , pr6
								, pr7
								, pr8
                            ) VALUES(
                                  '$pr1'
                                , '$pr2'
                                , '$pr3'
								, '$pr5'
								, '$pr6'
								, '$pr7'
								, '$pr8'
                            )";

    // echo $sql;
    $query = mysqli_query($connect, $sql);
    // $latestId = mysqli_insert_id($connect);
    
    if($query)
    {
        echo '<script type="text/javascript">
                alert("Record save successfully.");
                window.location.replace("pol.html");
            </script>';
    }
    else {
        $error = 'Failed to save records!';
    }
}

?>
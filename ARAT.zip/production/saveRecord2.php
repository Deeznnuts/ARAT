<?php
//Database connection
include 'dbconnect.php';

// initials
$error = "";
$success = "";
$sql = "";

//echo '<pre>';print_r($_POST);echo '</pre>';exit();

// when submit the form
if (isset($_POST['submit']))
{
    // Receiving POST Values
    
	$e1 = (isset($_POST["e1"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e1"]))) : "" );
	$e2 = (isset($_POST["e2"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e2"]))) : "" );
	$e3 = (isset($_POST["e3"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e3"]))) : "" );
	$e4 = (isset($_POST["e4"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e4"]))) : "" );
	$e5 = (isset($_POST["e5"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e5"]))) : "" );
	$e6 = (isset($_POST["e6"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e6"]))) : "" );
	$e7 = (isset($_POST["e7"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e7"]))) : "" );
	$e8 = (isset($_POST["e8"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e8"]))) : "" );
	$e9 = (isset($_POST["e9"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e9"]))) : "" );
	$e10 = (isset($_POST["e10"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e10"]))) : "" );
	$e11 = (isset($_POST["e11"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e11"]))) : "" );
	$e12 = (isset($_POST["e12"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e12"]))) : "" );
	$e13 = (isset($_POST["e13"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e13"]))) : "" );
	$e14 = (isset($_POST["e14"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e14"]))) : "" );
	$e15 = (isset($_POST["e15"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["e15"]))) : "" );

    // Insert the data into 'metrics2' table
    $sql = "INSERT INTO metrics2
                            (
                                  e1
								, e2
                                , e3
                                , e4
							    , e5
								, e6
								, e7
								, e8
								, e9
								, e10
								, e11
								, e12
								, e13
								, e14
								, e15
                            ) VALUES(
                                  '$e1'
                                , '$e2'
                                , '$e3'
								, '$e4'
								, '$e5'
								, '$e6'
								, '$e7'
								, '$e8'
								, '$e9'
								, '$e10'
								, '$e11'
								, '$e12'
								, '$e13'
								, '$e14'
								, '$e15'
                            )";

   //echo $sql;
    $query = mysqli_query($connect, $sql);
    // $latestId = mysqli_insert_id($connect);
    
    if($query)
    {
        echo '<script type="text/javascript">
                alert("Record save successfully.");
                window.location.replace("env.html");
            </script>';
    }
    else {
        $error = 'Failed to save records!';
    }
}

?>
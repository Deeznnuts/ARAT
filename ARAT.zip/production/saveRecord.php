<?php
//Database connection
include 'dbconnect.php';

// initials
$error = "";
$success = "";
$sql = "";

//echo '<pre>';print_r($_POST);echo '</pre>';exit();

// when submit the form
if (isset($_POST['submit']))
{
    // Receiving POST Values
    
	$t4 = (isset($_POST["t4"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t4"]))) : "" );
	$t5 = (isset($_POST["t5"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t5"]))) : "" );
	$t6 = (isset($_POST["t6"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t6"]))) : "" );
	$t8 = (isset($_POST["t8"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t8"]))) : "" );
	$t9 = (isset($_POST["t9"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t9"]))) : "" );
	$t10 = (isset($_POST["t10"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t10"]))) : "" );
	$t11 = (isset($_POST["t11"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t11"]))) : "" );
	$t12 = (isset($_POST["t12"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t12"]))) : "" );
	$t13 = (isset($_POST["t13"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t13"]))) : "" );
	$t15 = (isset($_POST["t15"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t15"]))) : "" );
	$t16 = (isset($_POST["t16"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t16"]))) : "" );
	$t17 = (isset($_POST["t17"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t17"]))) : "" );
	$t18 = (isset($_POST["t18"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t18"]))) : "" );
	$t22 = (isset($_POST["t22"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t22"]))) : "" );
	$t23 = (isset($_POST["t23"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t23"]))) : "" );
	$t24 = (isset($_POST["t24"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t24"]))) : "" );
	$t26 = (isset($_POST["t26"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t26"]))) : "" );
	$t27 = (isset($_POST["t27"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t27"]))) : "" );
	$t28 = (isset($_POST["t28"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t28"]))) : "" );
	$t30 = (isset($_POST["t30"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t30"]))) : "" );
	$t32 = (isset($_POST["t32"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t32"]))) : "" );
	$t33 = (isset($_POST["t33"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t33"]))) : "" );
	$t34 = (isset($_POST["t34"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t34"]))) : "" );
	$t35 = (isset($_POST["t35"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t35"]))) : "" );
	$t36 = (isset($_POST["t36"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t36"]))) : "" );
	$t37 = (isset($_POST["t37"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["t37"]))) : "" );

    // Insert the data into 'metrics' table
    $sql = "INSERT INTO metrics
                            (
                                  t4
								, t5
                                , t6
							    , t8
								, t9
								, t10
								, t11
								, t12
								, t13
								, t15
								, t16
								, t17
								, t18
								, t22
								, t23
								, t24
								, t26
								, t27
								, t28
								, t30
								, t32
								, t33
								, t34
								, t35
								, t36
								, t37
                            ) VALUES(
                                  '$t4'
                                , '$t5'
                                , '$t6'
								, '$t8'
								, '$t9'
								, '$t10'
								, '$t11'
								, '$t12'
								, '$t13'
								, '$t15'
								, '$t16'
								, '$t17'
								, '$t18'
								, '$t22'
								, '$t23'
								, '$t24'
								, '$t26'
								, '$t27'
								, '$t28'
								, '$t30'
								, '$t32'
								, '$t33'
								, '$t34'
								, '$t35'
								, '$t36'
								, '$t37'
                            )";

  // echo $sql;exit();
    $query = mysqli_query($connect, $sql);
    // $latestId = mysqli_insert_id($connect);
    
    if($query)
    {
        echo '<script type="text/javascript">
                alert("Record save successfully.");
                window.location.replace("tec.html");
            </script>';
    }
    else {
        $error = 'Failed to save records!';
    }
}

?>
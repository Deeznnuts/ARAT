<?php
//Database connection
include 'dbconnect.php';

// initials
$error = "";
$success = "";
$sql = "";

// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit();


// when submit the form
if (isset($_POST['name']))
{
    // Receiving POST Values
    $name  = (isset($_POST["name"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["name"]))) : "" );
    $phoneNumber    = (isset($_POST["phoneNumber"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["phoneNumber"]))) : "" );
    $address      = (isset($_POST["address"]) ? mysqli_escape_string($connect, trim(utf8_decode($_POST["address"]))) : "" );

    // Insert the data into 'users' table
    $sql = "INSERT INTO users
                            (
                                  name
                                , phoneNumber
                                , address
                            ) VALUES(
                                  '$name'
                                , '$phoneNumber'
                                , '$address'
                            )";

    // echo $sql;
    $query = mysqli_query($connect, $sql);
    // $latestId = mysqli_insert_id($connect);
    
    if($query)
    {
        // $msg = 'success';
        $displayHTML = '';

        // get existing records for display
        $sl = 1;

        $sqlString  = "SELECT id, name, phoneNumber, address FROM users ORDER BY id DESC;";
        $sqlQuery   = mysqli_query($connect, $sqlString) or die(mysqli_error($connect));
        $rows = ( $sqlQuery ) ? mysqli_num_rows($sqlQuery) : 0;
        
        if ( $rows > 0)
        {
            while( $record = mysqli_fetch_array($sqlQuery) )
            {
                $trEvenOdd = ( $sl % 2 ) == 0 ? 'class="even"' : '';

                $displayHTML .= '<tr '. $trEvenOdd .' >';
                    $displayHTML .= '<td style="text-align: center;">'. $sl++ .'</td>';
                    $displayHTML .= '<td><a href="#">'. $record["name"] .'</a></td>';
                    $displayHTML .= '<td>'. $record["phoneNumber"] .'</td>';
                    $displayHTML .= '<td><a href="#">'. $record["address"] .'</a></td>';
                $displayHTML .= '</tr>';

            }
        }
        else {
            $displayHTML .= '<tr>';
                $displayHTML .= '<td colspan="4"> No records found...</td>';
            $displayHTML .= '</tr>';

        }

        // return to display page
        echo $displayHTML;

    }
    else {
        // $msg = 'error';
        echo 'error';
    }
    // echo $msg;
}

?>